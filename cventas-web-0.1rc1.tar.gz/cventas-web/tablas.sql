CREATE TABLE `vendedores` (
`codigo` VARCHAR( 13 ) NOT NULL ,
`nombre` VARCHAR( 100 ) NOT NULL ,
`clave` VARCHAR( 10 ) NOT NULL ,
`nivel` VARCHAR( 1 ) NOT NULL ,
PRIMARY KEY ( `codigo` )
) ENGINE = MYISAM ;

CREATE TABLE `pedidos` (
`nropedido` VARCHAR( 10 ) NOT NULL ,
`fecha_ped` DATE NOT NULL ,
`codcli` VARCHAR( 15 ) NOT NULL ,
`monped` DOUBLE( 20, 2 ) NOT NULL ,
`cod_vend` VARCHAR( 13 ) NOT NULL ,
PRIMARY KEY ( `nropedido` )
) ENGINE = MYISAM ;

CREATE TABLE `detalle_ped` (
`nropedido` VARCHAR( 10 ) NOT NULL ,
`cod_art` VARCHAR( 20 ) NOT NULL ,
`cant_ord` DOUBLE( 20, 2 ) NOT NULL ,
`cant_ajust` DOUBLE( 20, 2 ) NOT NULL ,
`cant_desp` DOUBLE( 20, 2 ) NOT NULL ,
`cant_total` DOUBLE( 20, 2 ) NOT NULL ,
`precio` DOUBLE( 20, 2 ) NOT NULL
) ENGINE = MYISAM ;

CREATE TABLE `clientes` (
`codcli` VARCHAR( 15 ) NOT NULL ,
`nombre` VARCHAR( 100 ) NOT NULL ,
PRIMARY KEY ( `codcli` )
) ENGINE = MYISAM ;

