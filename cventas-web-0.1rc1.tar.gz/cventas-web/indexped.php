<?php
	session_start();	
	include ("funciones.php");
	head();
		
	if ($_SESSION['user']==""||$_SESSION['user']!=$_GET['vend'])
	   {
		echo "No ha iniciado ninguna session ";
		echo "<a href=index.php>volver</a>";
		session_close();	
		exit();
	   }

	$link=conectar();
	$vend=$_GET['vend'];
	$fecha=$_GET['fecha'];
	

	$sql="select * from vendedores where trim(codigo) = '$vend'";
	$result=mysql_query($sql,$link);
	$row=mysql_fetch_row($result);
	if ($row[0]==""){
	echo "Vendedor No &eacute;xiste";
	}
	else{

		echo "<table cellpadding=\"0px\" cellspacing=\"0px\" border=\"0\" > \n";
		echo "<tr> \n";
		echo "<td><b>Listado de Pedidos</b></td> \n";
		echo "</tr> \n";		
		echo "<tr> \n";
		echo "<td><b>Vendedor: $row[1] </b></td> \n";
		echo "</tr> \n";
		echo "<tr> \n";
		echo "<td><b>Mes: $fecha</b></td> \n";
		echo "</tr> \n";
		echo "</table> \n";
		$sql="select a.nropedido,a.fecha_ped,b.nombre from pedidos as a, clientes as b where 				trim(a.cod_vend) = '$vend' and a.codcli=b.codcli and a.fecha_ped between '".fecha_des($fecha)."' 				and '".fecha_has($fecha)."' order by a.fecha_ped";
	//echo $sql;
	$result=mysql_query($sql,$link);
		echo "<table ellpadding=\"0px\" cellspacing=\"0px\" border = \"1\"> \n";
		echo "<tr> \n";
		echo "<td><b>Nro Pedido</b></td> \n";
		echo "<td><b>Fecha</b></td> \n";
		echo "<td><b>Nombre Cliente</b></td> \n";	
		echo "</tr> \n";
		while ($row = mysql_fetch_row($result)){
			echo "<tr> \n";
			echo "<td><a href=\"detped.php?ped=$row[0]&fecha=$fecha\">$row[0]</a></td> \n";
			echo "<td>".cambiaf_a_normal($row[1])."</td> \n";
			echo "<td>$row[2]</td> \n";
			echo "</tr> \n";
			}
		echo "</table> \n";
		echo "<div aling=center><a href=logout.php>Cerrar Sesion</a></div> \n";	

	}
	foot();
?>
