<?php
	include ("funciones.php");	

	if (!empty($_POST['user']) && (!empty($_POST['passwd'])))
		{
		$user=$_POST['user'];
		$passwd=$_POST['passwd'];
		$fecha=$_POST['fecha'];
		$link=conectar();
		$sql="select * from vendedores where trim(codigo)='$user' and trim(clave)='$passwd'";
		$result=mysql_query($sql,$link);
		$row=mysql_fetch_row($result);
		if ($row>0)
		   {
		   session_start();
  		   session_register('user');
		   $_SESSION['Nombre'] = $row[1];
		   session_register('id_usuario');
		   $_SESSION['user'] = $user;
		   $url_relativa = "indexped.php?vend=$user&fecha=$fecha";
		   header("Location: http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/" .$url_relativa);

		   }else
			{echo "Nombre de usuario o Contraseña Incorrecta ";
			echo "<a href=index.php>volver</a>";			
			}			
		}
	else 
		{
		echo "Ningun Campo debe quedar vacio";
		};
?>
