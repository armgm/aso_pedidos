 <?php
	include("funciones.php"); 
	head();
 ?>

 <form id="form1" name="form1" method="post" action="autenticar.php">
  <table border='0'>
   <tr><td><img src="logo.jpg"/></td></tr>
   <tr>
	<td>Usuario:</td>
   </tr>	
   <tr>
	<td>
	    <input type="text" name="user" />
	</td>
   </tr>	
   <tr>
	<td>Clave:</td>
   </tr>	
   <tr>
	<td>
  	    <input type="password" name="passwd" />
	</td>
   </tr>
   <tr>
	<td>Mes:</td>
   </tr>		
   <tr>
	<td>
	    <select name='fecha'><option value=''>- seleccione -</option>
             <option value=septiembre>septiembre</option>
             <option value=octubre>Octubre</option>
             <option value=noviembre>Noviembre</option>
             <option value=diciembre>Diciembre</option>
            </select>
	  </td>
   </tr>   
   <tr>
	<td>		
	   <label>
	   <input type="submit" name="evnviar" value="Enviar" />
	   </label>
	   <label>
	   <input type="reset" name="borrar" value="borrar" />
	   </label>
	</td>
   </tr>
   		
  </table>	
</form>

<?php
	
foot();
?>
